export const environment = {
  production: true,
  baseUrl: "https://miesdinapen.tk/api",
};
